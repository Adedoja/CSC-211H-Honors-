/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Mazajme/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_pushButton_25_clicked",
    "",
    "on_pushButton_26_clicked",
    "on_NoF_2_clicked",
    "on_YesF_2_clicked",
    "on_NoA_3_clicked",
    "on_YesA_3_clicked",
    "on_pushButton_29_clicked",
    "on_pushButton_28_clicked",
    "on_pushButton_27_clicked",
    "on_label_12_linkActivated",
    "link",
    "on_pushButton_10_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_7_clicked",
    "on_KindOf_2_clicked",
    "on_Slightly_2_clicked",
    "on_Very_2_clicked",
    "on_pushButton_30_clicked",
    "on_pushButton_31_clicked",
    "on_pushButton_33_clicked",
    "on_on_2_clicked",
    "on_pushButton_clicked",
    "on_pushButton_24_clicked",
    "on_pushButton_32_clicked",
    "on_pushButton_4_clicked",
    "on_pushButton_52_clicked",
    "on_Bad_2_clicked",
    "on_Good_2_clicked",
    "on_Fair_2_clicked",
    "on_Great_2_clicked",
    "on_Terrible_2_clicked",
    "on_SadK_2_clicked",
    "on_SlightlySad_2_clicked",
    "on_veryS_4_clicked",
    "on_pushButton_34_clicked",
    "on_pushButton_35_clicked",
    "on_NoSu_2_clicked",
    "on_YesSu_2_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[80];
    char stringdata0[11];
    char stringdata1[25];
    char stringdata2[1];
    char stringdata3[25];
    char stringdata4[17];
    char stringdata5[18];
    char stringdata6[17];
    char stringdata7[18];
    char stringdata8[25];
    char stringdata9[25];
    char stringdata10[25];
    char stringdata11[26];
    char stringdata12[5];
    char stringdata13[25];
    char stringdata14[25];
    char stringdata15[24];
    char stringdata16[20];
    char stringdata17[22];
    char stringdata18[18];
    char stringdata19[25];
    char stringdata20[25];
    char stringdata21[25];
    char stringdata22[16];
    char stringdata23[22];
    char stringdata24[25];
    char stringdata25[25];
    char stringdata26[24];
    char stringdata27[25];
    char stringdata28[17];
    char stringdata29[18];
    char stringdata30[18];
    char stringdata31[19];
    char stringdata32[22];
    char stringdata33[18];
    char stringdata34[25];
    char stringdata35[19];
    char stringdata36[25];
    char stringdata37[25];
    char stringdata38[18];
    char stringdata39[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 24),  // "on_pushButton_25_clicked"
        QT_MOC_LITERAL(36, 0),  // ""
        QT_MOC_LITERAL(37, 24),  // "on_pushButton_26_clicked"
        QT_MOC_LITERAL(62, 16),  // "on_NoF_2_clicked"
        QT_MOC_LITERAL(79, 17),  // "on_YesF_2_clicked"
        QT_MOC_LITERAL(97, 16),  // "on_NoA_3_clicked"
        QT_MOC_LITERAL(114, 17),  // "on_YesA_3_clicked"
        QT_MOC_LITERAL(132, 24),  // "on_pushButton_29_clicked"
        QT_MOC_LITERAL(157, 24),  // "on_pushButton_28_clicked"
        QT_MOC_LITERAL(182, 24),  // "on_pushButton_27_clicked"
        QT_MOC_LITERAL(207, 25),  // "on_label_12_linkActivated"
        QT_MOC_LITERAL(233, 4),  // "link"
        QT_MOC_LITERAL(238, 24),  // "on_pushButton_10_clicked"
        QT_MOC_LITERAL(263, 24),  // "on_pushButton_11_clicked"
        QT_MOC_LITERAL(288, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(312, 19),  // "on_KindOf_2_clicked"
        QT_MOC_LITERAL(332, 21),  // "on_Slightly_2_clicked"
        QT_MOC_LITERAL(354, 17),  // "on_Very_2_clicked"
        QT_MOC_LITERAL(372, 24),  // "on_pushButton_30_clicked"
        QT_MOC_LITERAL(397, 24),  // "on_pushButton_31_clicked"
        QT_MOC_LITERAL(422, 24),  // "on_pushButton_33_clicked"
        QT_MOC_LITERAL(447, 15),  // "on_on_2_clicked"
        QT_MOC_LITERAL(463, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(485, 24),  // "on_pushButton_24_clicked"
        QT_MOC_LITERAL(510, 24),  // "on_pushButton_32_clicked"
        QT_MOC_LITERAL(535, 23),  // "on_pushButton_4_clicked"
        QT_MOC_LITERAL(559, 24),  // "on_pushButton_52_clicked"
        QT_MOC_LITERAL(584, 16),  // "on_Bad_2_clicked"
        QT_MOC_LITERAL(601, 17),  // "on_Good_2_clicked"
        QT_MOC_LITERAL(619, 17),  // "on_Fair_2_clicked"
        QT_MOC_LITERAL(637, 18),  // "on_Great_2_clicked"
        QT_MOC_LITERAL(656, 21),  // "on_Terrible_2_clicked"
        QT_MOC_LITERAL(678, 17),  // "on_SadK_2_clicked"
        QT_MOC_LITERAL(696, 24),  // "on_SlightlySad_2_clicked"
        QT_MOC_LITERAL(721, 18),  // "on_veryS_4_clicked"
        QT_MOC_LITERAL(740, 24),  // "on_pushButton_34_clicked"
        QT_MOC_LITERAL(765, 24),  // "on_pushButton_35_clicked"
        QT_MOC_LITERAL(790, 17),  // "on_NoSu_2_clicked"
        QT_MOC_LITERAL(808, 18)   // "on_YesSu_2_clicked"
    },
    "MainWindow",
    "on_pushButton_25_clicked",
    "",
    "on_pushButton_26_clicked",
    "on_NoF_2_clicked",
    "on_YesF_2_clicked",
    "on_NoA_3_clicked",
    "on_YesA_3_clicked",
    "on_pushButton_29_clicked",
    "on_pushButton_28_clicked",
    "on_pushButton_27_clicked",
    "on_label_12_linkActivated",
    "link",
    "on_pushButton_10_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_7_clicked",
    "on_KindOf_2_clicked",
    "on_Slightly_2_clicked",
    "on_Very_2_clicked",
    "on_pushButton_30_clicked",
    "on_pushButton_31_clicked",
    "on_pushButton_33_clicked",
    "on_on_2_clicked",
    "on_pushButton_clicked",
    "on_pushButton_24_clicked",
    "on_pushButton_32_clicked",
    "on_pushButton_4_clicked",
    "on_pushButton_52_clicked",
    "on_Bad_2_clicked",
    "on_Good_2_clicked",
    "on_Fair_2_clicked",
    "on_Great_2_clicked",
    "on_Terrible_2_clicked",
    "on_SadK_2_clicked",
    "on_SlightlySad_2_clicked",
    "on_veryS_4_clicked",
    "on_pushButton_34_clicked",
    "on_pushButton_35_clicked",
    "on_NoSu_2_clicked",
    "on_YesSu_2_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  236,    2, 0x08,    1 /* Private */,
       3,    0,  237,    2, 0x08,    2 /* Private */,
       4,    0,  238,    2, 0x08,    3 /* Private */,
       5,    0,  239,    2, 0x08,    4 /* Private */,
       6,    0,  240,    2, 0x08,    5 /* Private */,
       7,    0,  241,    2, 0x08,    6 /* Private */,
       8,    0,  242,    2, 0x08,    7 /* Private */,
       9,    0,  243,    2, 0x08,    8 /* Private */,
      10,    0,  244,    2, 0x08,    9 /* Private */,
      11,    1,  245,    2, 0x08,   10 /* Private */,
      13,    0,  248,    2, 0x08,   12 /* Private */,
      14,    0,  249,    2, 0x08,   13 /* Private */,
      15,    0,  250,    2, 0x08,   14 /* Private */,
      16,    0,  251,    2, 0x08,   15 /* Private */,
      17,    0,  252,    2, 0x08,   16 /* Private */,
      18,    0,  253,    2, 0x08,   17 /* Private */,
      19,    0,  254,    2, 0x08,   18 /* Private */,
      20,    0,  255,    2, 0x08,   19 /* Private */,
      21,    0,  256,    2, 0x08,   20 /* Private */,
      22,    0,  257,    2, 0x08,   21 /* Private */,
      23,    0,  258,    2, 0x08,   22 /* Private */,
      24,    0,  259,    2, 0x08,   23 /* Private */,
      25,    0,  260,    2, 0x08,   24 /* Private */,
      26,    0,  261,    2, 0x08,   25 /* Private */,
      27,    0,  262,    2, 0x08,   26 /* Private */,
      28,    0,  263,    2, 0x08,   27 /* Private */,
      29,    0,  264,    2, 0x08,   28 /* Private */,
      30,    0,  265,    2, 0x08,   29 /* Private */,
      31,    0,  266,    2, 0x08,   30 /* Private */,
      32,    0,  267,    2, 0x08,   31 /* Private */,
      33,    0,  268,    2, 0x08,   32 /* Private */,
      34,    0,  269,    2, 0x08,   33 /* Private */,
      35,    0,  270,    2, 0x08,   34 /* Private */,
      36,    0,  271,    2, 0x08,   35 /* Private */,
      37,    0,  272,    2, 0x08,   36 /* Private */,
      38,    0,  273,    2, 0x08,   37 /* Private */,
      39,    0,  274,    2, 0x08,   38 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_pushButton_25_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_26_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_NoF_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_YesF_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_NoA_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_YesA_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_29_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_28_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_27_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_label_12_linkActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_pushButton_10_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_11_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_KindOf_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Slightly_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Very_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_30_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_31_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_33_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_on_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_24_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_32_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_52_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Bad_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Good_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Fair_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Great_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Terrible_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SadK_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SlightlySad_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_veryS_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_34_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_35_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_NoSu_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_YesSu_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_25_clicked(); break;
        case 1: _t->on_pushButton_26_clicked(); break;
        case 2: _t->on_NoF_2_clicked(); break;
        case 3: _t->on_YesF_2_clicked(); break;
        case 4: _t->on_NoA_3_clicked(); break;
        case 5: _t->on_YesA_3_clicked(); break;
        case 6: _t->on_pushButton_29_clicked(); break;
        case 7: _t->on_pushButton_28_clicked(); break;
        case 8: _t->on_pushButton_27_clicked(); break;

        case 10: _t->on_pushButton_10_clicked(); break;
        case 11: _t->on_pushButton_11_clicked(); break;
        case 12: _t->on_pushButton_7_clicked(); break;
        case 13: _t->on_KindOf_2_clicked(); break;
        case 14: _t->on_Slightly_2_clicked(); break;
        case 15: _t->on_Very_2_clicked(); break;
        case 16: _t->on_pushButton_30_clicked(); break;
        case 17: _t->on_pushButton_31_clicked(); break;
        case 18: _t->on_pushButton_33_clicked(); break;
        case 19: _t->on_on_2_clicked(); break;
        case 20: _t->on_pushButton_clicked(); break;
        case 21: _t->on_pushButton_24_clicked(); break;
        case 22: _t->on_pushButton_32_clicked(); break;
        case 23: _t->on_pushButton_4_clicked(); break;
        case 24: _t->on_pushButton_52_clicked(); break;
        case 25: _t->on_Bad_2_clicked(); break;
        case 26: _t->on_Good_2_clicked(); break;
        case 27: _t->on_Fair_2_clicked(); break;
        case 28: _t->on_Great_2_clicked(); break;
        case 29: _t->on_Terrible_2_clicked(); break;
        case 30: _t->on_SadK_2_clicked(); break;
        case 31: _t->on_SlightlySad_2_clicked(); break;
        case 32: _t->on_veryS_4_clicked(); break;
        case 33: _t->on_pushButton_34_clicked(); break;
        case 34: _t->on_pushButton_35_clicked(); break;
        case 35: _t->on_NoSu_2_clicked(); break;
        case 36: _t->on_YesSu_2_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 37;
    }
    return _id;
}
QT_WARNING_POP
